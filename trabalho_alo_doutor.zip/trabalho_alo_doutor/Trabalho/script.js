document.querySelectorAll('header nav button, footer button').forEach(button => {
    button.addEventListener('click', () => {
        // Remove a classe ativa de todos os botões
        document.querySelectorAll('header nav button, footer button').forEach(btn => btn.classList.remove('active'));

        // Adiciona a classe ativa ao botão clicado
        button.classList.add('active');

        // Identifica o texto do botão clicado
        const section = button.textContent.trim();
        const infoDiv = document.getElementById('info');

        // Se o botão for "Usuário", redireciona para o usuario.html ou usuario_dark.html
        if (section === "Usuário") {
            // Verifica se o tema é escuro ou claro
            const currentTheme = document.querySelector('link[rel="stylesheet"]').getAttribute('href');

            if (currentTheme === 'style_final_edition.css') {
                // Modo claro, redireciona para usuario.html
                window.location.href = 'usuario.html';
            } else {
                // Modo escuro, redireciona para usuario_dark.html
                window.location.href = 'usuario_dark.html';
            }
            return; // Interrompe a execução do restante do código
        }

        // Se o botão for "Prontuário", redireciona para o prontuario.html ou prontuario_dark.html
        if (section === "Prontuário") {
            // Verifica se o tema é escuro ou claro
            const currentTheme = document.querySelector('link[rel="stylesheet"]').getAttribute('href');

            if (currentTheme === 'style_final_edition.css') {
                // Modo claro, redireciona para prontuario.html
                window.location.href = 'prontuario.html';
            } else {
                // Modo escuro, redireciona para prontuario_dark.html
                window.location.href = 'prontuario_dark.html';
            }
            return; // Interrompe a execução do restante do código
        }

        // Se o botão for "Fale Conosco", exibe as informações de contato
        if (section === "Fale Conosco") {
            infoDiv.innerHTML = `
                <h2>Fale Conosco</h2>
                <p><strong>Canoas:</strong><br>
                (51) 3463.xxxx<br>
                (51) 3060.xxxx<br>
                (51) 9 8350.xxxx<br>
                End: Caçapava xx em frente ao HPS.</p>
                <br>
                <p><strong>Charqueadas:</strong><br>
                (51) 2143.xxxx<br>
                (51) 9 8955.xxxx<br>
                End: Orvalino Dorneles - xxx</p>
                <br>
                <p><strong>Triunfo:</strong><br>
                (51) 3654.xxxx<br>
                (51) 9 8955.xxxx</p>
            `;
            return; // Interrompe a execução do restante do código
        }

        // Se o botão for "Acessibilidade", exibe as opções para trocar o estilo
        if (section === "Acessibilidade") {
            // Limpa o conteúdo da div de informações
            infoDiv.innerHTML = `<h2>Acessibilidade</h2>`;

            // Adiciona o texto "Alterar modo de luz"
            const descricao = document.createElement('p');
            descricao.textContent = "Alterar modo de luz:";
            infoDiv.appendChild(descricao);

            // Cria o botão para alternar o modo de luz
            const alterarModoButton = document.createElement('button');
            alterarModoButton.textContent = "Ativar Modo Escuro";
            alterarModoButton.classList.add('botao', 'ativar-claro'); // Classe 'botao' para todos os botões
            infoDiv.appendChild(alterarModoButton);

            // Adiciona evento ao botão de alternar modo
            alterarModoButton.addEventListener('click', () => {
                const currentTheme = document.querySelector('link[rel="stylesheet"]');

                if (currentTheme.getAttribute('href') === 'style_final_edition.css') {
                    // Troca para o modo escuro no site principal
                    currentTheme.setAttribute('href', 'modo_dark_home.style.css');
                    alterarModoButton.textContent = "Ativar Modo Claro";
                    alterarModoButton.classList.remove('ativar-claro');
                    alterarModoButton.classList.add('ativar-escuro');
                } else {
                    // Volta ao modo claro no site principal
                    currentTheme.setAttribute('href', 'style_final_edition.css');
                    alterarModoButton.textContent = "Ativar Modo Escuro";
                    alterarModoButton.classList.remove('ativar-escuro');
                    alterarModoButton.classList.add('ativar-claro');
                }

                // Verifica se está na página "prontuario.html" e troca o CSS específico
                if (window.location.pathname.includes('prontuario.html')) {
                    const prontuarioStyle = document.getElementById('prontuario-style');
                    if (prontuarioStyle.getAttribute('href') === 'style_prontuario.css') {
                        prontuarioStyle.setAttribute('href', 'style_prontuario_dark.css');
                    } else {
                        prontuarioStyle.setAttribute('href', 'style_prontuario.css');
                    }
                }
            });

            // Criação do botão para aumentar o tamanho das fontes
            const aumentarFontesButton = document.createElement('button');
            aumentarFontesButton.textContent = "Aumentar Tamanho da Fonte";
            aumentarFontesButton.classList.add('aumentar-fontes-button');
            infoDiv.appendChild(aumentarFontesButton);

            // Criação do botão para diminuir o tamanho das fontes
            const diminuirFontesButton = document.createElement('button');
            diminuirFontesButton.textContent = "Diminuir Tamanho da Fonte";
            diminuirFontesButton.classList.add('diminuir-fontes-button');
            infoDiv.appendChild(diminuirFontesButton);

            // Variável para controlar o tamanho da fonte
            let fontSize = 16; // Tamanho de fonte inicial

            // Evento para aumentar o tamanho da fonte
            aumentarFontesButton.addEventListener('click', () => {
                fontSize += 2; // Aumenta o tamanho da fonte em 2px
                document.body.style.fontSize = fontSize + "px"; // Aplica o novo tamanho
            });

            // Evento para diminuir o tamanho da fonte
            diminuirFontesButton.addEventListener('click', () => {
                fontSize = Math.max(12, fontSize - 2); // Diminui o tamanho da fonte, mas não vai abaixo de 12px
                document.body.style.fontSize = fontSize + "px"; // Aplica o novo tamanho
            });

            return; // Sai da função para evitar executar o restante do código
        }

        // Código para outros botões
        if (section !== 'Agendamentos') {
            infoDiv.innerHTML = `<h2>${section}</h2>`;
            infoDiv.innerHTML += `<p>Aqui vão as informações detalhadas sobre ${section.toLowerCase()}.</p>`;
            return;
        }

        // Código para Agendamentos (não alterado)
        infoDiv.innerHTML = `<h2>Agendamentos</h2>`; // Título para agendamentos

        // Seleção de Profissionais
        const profissionalSelect = document.createElement('select');
        const profissionais = [
            "Dr. Silva - Urologia",
            "Dr. Santos - Gastrom",
            "Dr. Oliveira - Reumatologia",
            "Dr. Costa - Traumatologia",
            "Dr. Ferreira - Psiquiatria",
            "Dr. Almeida - Dermatologia",
            "Dr. Lima - Proctologia",
            "Dr. Rocha - Ginecologia",
            "Dr. Pereira - Endocrinologia",
            "Dr. Martins - Pediatria",
            "Dr. Dias - Clínico",
            "Dr. Nascimento - Psicologia"
        ];
        profissionais.forEach(prof => {
            const option = document.createElement('option');
            option.value = prof;
            option.textContent = prof;
            profissionalSelect.appendChild(option);
        });
        infoDiv.appendChild(document.createTextNode("Selecione o profissional: "));
        infoDiv.appendChild(profissionalSelect);

        // Seleção de Datas
        const dataSelect = document.createElement('select');
        const startDate = new Date("2024-11-01");
        const endDate = new Date("2025-01-31");
        let currentDate = startDate;

        while (currentDate <= endDate) {
            if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) {
                const option = document.createElement('option');
                option.value = currentDate.toISOString().split('T')[0];
                option.textContent = currentDate.toLocaleDateString('pt-BR');
                dataSelect.appendChild(option);
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }
        infoDiv.appendChild(document.createElement("br"));
        infoDiv.appendChild(document.createTextNode("Selecione a data: "));
        infoDiv.appendChild(dataSelect);

        // Seleção de Horários
        const horarioSelect = document.createElement('select');
        const horarios = ["08:00", "09:00", "10:00", "11:00", "12:00"];
        horarios.forEach(horario => {
            const option = document.createElement('option');
            option.value = horario;
            option.textContent = horario;
            horarioSelect.appendChild(option);
        });
        infoDiv.appendChild(document.createElement("br"));
        infoDiv.appendChild(document.createTextNode("Selecione o horário: "));
        infoDiv.appendChild(horarioSelect);

        // Botão Marcar
        const marcarButton = document.createElement('button');
        marcarButton.textContent = "Marcar";
        marcarButton.classList.add('marcar-button');
        infoDiv.appendChild(document.createElement("br"));
        infoDiv.appendChild(marcarButton);

        // Div para exibir agendamentos
        const agendamentosDiv = document.createElement('div');
        agendamentosDiv.style.marginTop = "20px";
        agendamentosDiv.style.padding = "15px";
        agendamentosDiv.style.border = "1px solid #ddd";
        agendamentosDiv.style.borderRadius = "8px";
        infoDiv.appendChild(agendamentosDiv);

        // Texto de observação
        const observacao = document.createElement('p');
        observacao.textContent = "OBS: Será feita uma ligação para confirmar o atendimento 3 dias antes.";
        observacao.classList.add('observacao-texto');
        infoDiv.appendChild(observacao);

        // Evento para Marcar
        marcarButton.addEventListener('click', () => {
            const profissional = profissionalSelect.value;
            const data = dataSelect.value;
            const horario = horarioSelect.value;

            if (profissional && data && horario) {
                const agendamentoTexto = document.createElement('div');
                agendamentoTexto.innerHTML = `<p><strong>Profissional:</strong> ${profissional} | <strong>Data:</strong> ${new Date(data).toLocaleDateString('pt-BR')} | <strong>Horário:</strong> ${horario}</p>`;

                // Botão de Desmarcar
                const desmarcarButton = document.createElement('button');
                desmarcarButton.textContent = "Desmarcar";
                desmarcarButton.classList.add('desmarcar-button');
                agendamentoTexto.appendChild(desmarcarButton);
                agendamentosDiv.appendChild(agendamentoTexto);

                desmarcarButton.addEventListener('click', () => {
                    agendamentosDiv.removeChild(agendamentoTexto);
                });
            } else {
                alert("Por favor, preencha todas as informações.");
            }
        });
    });
});
